import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
 
@Component({
  selector: 'page-mess-detail',
  templateUrl: 'mess-detail.html',
})
export class MessDetailPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

}
