import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular'; 
import { HotelService } from '../hotel/hotel.service';
import { HotelHomePage } from '../hotel-home/hotel-home';


@Component({
  selector: 'page-all-list',
  templateUrl: 'all-list.html',
  providers: [HotelService]
})
export class AllListPage {
  public displayData;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams, 
              private hotelService: HotelService) {

    this.hotelService.getHotelData()
      .subscribe(data => {
        this.displayData = data;
      });

  }

  navigateToHotel(id: number) {
    this.navCtrl.push(HotelHomePage, { 'id': id });
  }


}
